<header class="header text-center text-white mb-4" style="background-image: linear-gradient(-225deg, #5D9FFF 0%, #B8DCFF 48%, #6BBBFF 100%);">
    <div class="container">

        <div class="row">
            <div class="col-md-8 mx-auto">

                <h1 class="text-warning">صحتك</h1>
                <p class=" mt-6" style="font-size: 3rem">دليلك لحياة صحيّة</p>

            </div>
        </div>

    </div>
</header><!-- /.header -->
