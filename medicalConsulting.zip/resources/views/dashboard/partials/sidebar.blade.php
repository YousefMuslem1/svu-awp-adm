    <ul class="list-group">
        <li class="list-group-item"><a href="{{route('dashboard.home')}}">الرئيسية</a></li>
        <li class="list-group-item"><a href="{{route('dashboard.categories.index')}}">إدارة الأقسام</a></li>
        <li class="list-group-item"><a href="{{route('dashboard.articles.index')}}">إدارة المقالات</a></li>
        <li class="list-group-item"><a href="{{route('dashboard.consultations.index')}}">إدارة الإستشارات</a></li>


    </ul>
    <ul class="list-group mt-3">
        <li class="list-group-item "><a href="{{route('dashboard.trash')}}" class="text-danger">سلة المحذوفات </a></li>
    </ul>
