<?php $__env->startSection('content'); ?>
    <section class="section bg-gray p-0" >
        <div class="container">
            <h2 class="lead-4 text-center text-warning" style="direction: rtl">مقالات عن <?php echo e($articles[0]->category->name); ?></h2>
            <div class="row">

                <div class="col-md-10 col-xl-9 mx-auto">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card hover-shadow-7 my-8">
                        <div class="row">
                            <div class="col-md-4">
                                <a href="blog-single.html">
                                    <img class="fit-cover position-absolute h-100" src="<?php echo e(asset('storage/'.$article->image)); ?>" alt="...">
                                </a>
                            </div>

                            <div class="col-md-8">
                                <div class="p-7" style="direction: rtl">
                                    <h4><?php echo e($article->title); ?></h4>
                                    <p class="description"><?php echo $article->description; ?></p>
                                    <a class="small ls-1" href="<?php echo e(route('show.article', $article->id)); ?>"> <span class="pl-1">&xrarr;</span>المزيد</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <?php echo e($articles->links()); ?>


                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/limit.text.min.js')); ?>"></script>
    <script>
        $('.description').limitText({
            length: 100,
            ellipsisText: '...'
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/categories/get_categories_articles.blade.php ENDPATH**/ ?>