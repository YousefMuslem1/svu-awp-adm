<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <a href="<?php echo e(route('dashboard.category.trash')); ?>">الأقسام المحذوفة</a>
                    <span class="badge badge-primary badge-pill"><?php echo e($categoriesTrashedCount); ?></span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <a href="<?php echo e(route('dashboard.article.trash')); ?>">المقالات المحذوفة</a>
                    <span class="badge badge-primary badge-pill"><?php echo e($articlesTrashedCount); ?></span>
                </li>
            </ul>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/trash/get_trash.blade.php ENDPATH**/ ?>