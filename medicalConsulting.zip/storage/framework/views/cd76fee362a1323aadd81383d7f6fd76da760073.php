<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-10">
            <ul class="list-group">
                <?php $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item lead mb-2">
                        <h6 class="m-0 p-0"><a href="#" class="m-0 p-0"><?php echo e($consultation->consult_add); ?></a></h6>
                        <span class="m-0 p-0" style="font-size: .7rem">
                            <i class="fas fa-history"></i>
                            <?php echo e(date('F d, Y', strtotime($consultation->created_at))); ?> at <?php echo e(date('g:ia')); ?>

                        </span><br>
                        <p><span class="text-info"> المرسل : </span> <?php echo e($consultation->user->name); ?></p>
                        <h6>
                            <span class="text-secondary">الحالة : </span>
                            <span class="text-danger">
                                <?php if(!$consultation->is_replayed): ?>  لم يتم الرد بعد
                                    <?php else: ?>  <span class="text-success"> تم الرد</span>
                                <?php endif; ?></span>
                        </h6>
                        <?php if(!$consultation->is_replayed): ?>
                            <a href="<?php echo e(route('dashboard.consultations.show', $consultation->id)); ?>" class="btn btn-success float-left"> قراءة ورد <i class="fas fa-comment-dots"></i></a>
                        <?php else: ?>
                            <a href="<?php echo e(route('dashboard.consultations.show', $consultation->id)); ?>" class="btn btn-secondary float-left"> مشاهدة <i class="fas fa-eye"></i></a>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/consultations/index.blade.php ENDPATH**/ ?>