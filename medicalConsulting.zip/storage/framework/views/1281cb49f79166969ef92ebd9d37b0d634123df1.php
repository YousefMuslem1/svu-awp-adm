<?php $__env->startSection('content'); ?>
    <h2 class="text-secondary">إدارة المقالات</h2>
    <hr>
    <a href="<?php echo e(route('dashboard.articles.create')); ?>" class="btn btn-success mb-3"> <i class="fas fa-plus mr-2"></i>أضف مقالة </a>

    <div class="card card-default">
        <div class="card-header">
            المقالات
        </div>
        <div class="card-body">

            <table class="table table-hover">
                <thead style="font-size: .8rem">
                <th>عنوان المقالة</th>
                <th>الوصف</th>
                <th>عدد الزوار</th>
                <th>تاريخ الإنشاء</th>
                <th>تاريخ آخر تعديل</th>
                <th>القسم الحاوي</th>
                <th>الغلاف</th>
                <th></th>
                <th></th>
                <th></th>
                </thead>
                <tbody class="lead categories" style="font-size: 1.1rem">

                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td >
                            <a class="title"
                               href="<?php echo e(route('dashboard.articles.show', $article->id)); ?>" target="_blank" title="<?php echo e($article->title); ?>"><?php echo e($article->title); ?></a>
                        </td>
                        <td class="description" title="<?php echo e($article->description); ?> "><?php echo $article->description; ?> </td>
                        <td>
                            <span class="badge badge-warning"><?php echo e($article->view_count); ?></span>
                        </td>
                        <td style="font-size: .8rem">
                            <?php echo e(date('F d, Y', strtotime($article->created_at))); ?> at <?php echo e(date('g:ia')); ?>

                        </td>
                        <td style="font-size: .8rem">
                            <?php echo e(date('F d, Y', strtotime($article->updated_at))); ?> at <?php echo e(date('g:ia')); ?>

                        </td>
                        <td class="category"><?php echo e($article->category->name); ?></td>
                        <td>
                            <img src="<?php echo e(asset('/storage/'.$article->image)); ?>" alt="<?php echo e($article->name); ?>" width="90px" height="70px">
                        </td>
                        <td>
                            <button
                                class="btn btn-danger btn-sm m-0"
                                data-title="<?php echo e($article->title); ?>"
                                data-toggle="modal"
                                data-target="#deleteArticle"
                                onclick="handleDelete(<?php echo e($article->id); ?>)"
                                title="حذف"
                                style="cursor: pointer"><i class="fas fa-trash-alt"></i></button>
                        </td>
                        <td>
                            <a class="btn btn-secondary btn-sm" href="<?php echo e(route('dashboard.articles.show', $article->id)); ?>" target="_blank" title="مشاهدة ">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('dashboard.articles.edit', $article->id)); ?>"
                               class="btn btn-info btn-sm m-0"
                               style="cursor: pointer"
                               title="تعديل"
                            ><i class="fas fa-edit"></i>
                            </a>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo $articles->links(); ?>

            <?php if(count($articles) == 0): ?>
                <div class="alert alert-info lead">لم تتم إضافة أي مقالة بعد
                    <a href="<?php echo e(route('dashboard.articles.create')); ?>">أنشئ الآن</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('.description').limitText({
            length: 18,
            ellipsisText: '...'
        }).css('color', '#800000');
        $('.title').limitText({
            length: 12,
            ellipsisText: '...'
        }).css('color', '#800000');
        $('.category').limitText({
            length: 20,
            ellipsisText: '...'
        }).css('color', '#800000');

        //Delete a category
        $('.modal').on('hidden.bs.modal', function (e) {
            $(this).find("#d-head").html('').end()
        })
        // Reset inputs in modal after hiden from user
        $('#deleteArticle').on('show.bs.modal', function (e) {
            var button = $(e.relatedTarget)
            var title = button.data('title');
            var modal = $(this)
            modal.find('.modal-body #d-head').append(title + ' ') ;

        })
        function handleDelete(id) {

            var form = document.getElementById('deleteFormArticle');
            form.action = '/dashboard/articles/' + id;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.partials.articles.delete_article_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/articles/index.blade.php ENDPATH**/ ?>