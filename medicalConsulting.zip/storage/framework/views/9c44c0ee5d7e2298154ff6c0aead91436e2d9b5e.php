<?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/trix.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">

        <div class="col-md-10">
            <div class="card card-default">
                <div class="card-header">
                    نظام الاستشارة  الطلبات الواردة
                </div>
                <div class="card-body">
                        <h6 class="lead">
                            <span class="text-danger">عنوان الاستشارة : </span>
                            <p class=" d-inline"><?php echo e($consultation->consult_add); ?></p>
                            <?php if($consultation->is_replayed): ?>
                                <span class="badge badge-success">تم الرد</span>
                            <?php else: ?>
                                <span class="badge badge-danger">لم يتم الرد</span>
                            <?php endif; ?>
                        </h6>
                    <br>
                    <h6 class="lead">
                        <span class=" text-danger">تاريخ الاستشارة : </span>
                        <p class=" d-inline ">
                            <?php echo e(date('F d, Y', strtotime($consultation->created_at))); ?> at <?php echo e(date('g:ia')); ?>

                        </p>
                    </h6>
                    <br>     <h6 class="lead">
                        <span class=" text-danger">المرسل : </span>
                        <p class=" d-inline "><?php echo e($consultation->user->name); ?></p>
                    </h6>
                    <br>
                    <h6 class="lead">
                        <span class=" text-danger">العمر : </span>
                        <p class=" d-inline "><?php echo e($consultation->age); ?></p>
                    </h6>
                    <br>
                    <h6 class="lead">
                        <span class=" text-danger">الجنس : </span>
                        <p class=" d-inline "><?php echo e($consultation->gender); ?></p>
                    </h6>
                    <br>
                    <h6 class="lead">
                        <span class=" text-danger">التاريخ المرضي : </span>
                        <p class=" d-inline "><?php echo $consultation->dis_history; ?></p>
                    </h6>
                    <br>
                    <h6 class="lead">
                        <span class=" text-danger">نص الاستشارة : </span> <br>
                        <p class=" d-inline p-3 ml-5"><?php echo $consultation->consult_body; ?></p>
                    </h6>

                    <form action="<?php echo e(route('dashboard.consultation.replay', $consultation->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="replay" class="lead text-danger">نص الرد: </label>
                            <?php if(!$consultation->is_replayed): ?>
                                <input id="replay" type="hidden" name="replay">
                                <trix-editor input="replay" placeholder="يمكن تنسيق الرد من خلال الخيارت في الأعلى" ></trix-editor>
                            <?php else: ?>
                                <p><?php echo $consultation->admin_replay; ?></p>
                            <?php endif; ?>
                        </div>
                        <?php if(!$consultation->is_replayed): ?>
                        <input type="submit" class="btn btn-success" value="إرسال رد">
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/trix.min.js')); ?>"> </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/consultations/show.blade.php ENDPATH**/ ?>