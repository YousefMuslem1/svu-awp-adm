<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary "><i class="fas fa-undo-alt"></i>  رجــوع</a>
    <div class="row ml-3 mt-4">
        <div class="col-md-10">
            <h2>
                <?php echo e($article->title); ?>

                <a href="<?php echo e(route('dashboard.articles.edit', $article->id)); ?>" class="btn btn-success btn-sm float-left"><i class="fas fa-edit"></i> تعديل</a>
            </h2>
            <span class="text-secondary" style="font-size: .7rem"><i class="fas fa-history"></i>
            <?php echo e(date('F d, Y', strtotime($article->created_at))); ?> at <?php echo e(date('g:ia')); ?>

            </span><br>
            القسم :<span class="text-secondary">  <?php echo e($article->category->name); ?> </span>
            <img src="<?php echo e(asset('/storage/'.$article->image)); ?>" alt="<?php echo e($article->name); ?>" class="img-thumbnail my-4">
            <p><?php echo $article->description; ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/articles/show.blade.php ENDPATH**/ ?>