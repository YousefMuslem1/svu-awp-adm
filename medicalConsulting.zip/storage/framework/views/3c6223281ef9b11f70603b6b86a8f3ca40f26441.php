<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div>
            <a href="<?php echo e(route('dashboard.articles.show', $article->id)); ?>"><?php echo e($article->title); ?></a>
            <p class="description"><?php echo e($article->description); ?></p>
        </div>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('.description').limitText({
            length: 90,
            ellipsisText: '...'
        }).css('color', '#868E96');

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/categories/get_articles.blade.php ENDPATH**/ ?>