<?php echo $__env->make('dashboard.partials.articles.delete_article_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row ml-3">
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-3">
                <div class="card" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title" title="<?php echo e($article->description); ?>"><?php echo e($article->title); ?> </h5>

                        <form action="<?php echo e(route('dashboard.articles.restore', $article->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button
                                type="button"
                                class="btn btn-danger"
                                data-toggle="modal"
                                data-title="<?php echo e($article->title); ?>"
                                data-target="#deleteArticle"
                                onclick=handleDelete(<?php echo e($article->id); ?>)
                            >حذف نهائي</button>
                            <button type="submit" class="btn btn-success">استعادة</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <?php if(count($articles) == 0): ?>
        <div class="alert alert-info lead">لاتوجد مقالات محذوفة </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        //Delete a category
        $('.modal').on('hidden.bs.modal', function (e) {
            $(this).find("#d-head").html('').end()
        })
        // Reset inputs in modal after hiden from user
        $('#deleteArticle').on('show.bs.modal', function (e) {
            var button = $(e.relatedTarget)
            var name = button.data('title');
            var modal = $(this)
            modal.find('.modal-body #d-head').append(name + ' ') ;

        })

        function handleDelete(id) {
            console.log(id)
            var form = document.getElementById('deleteFormArticle');
            form.action = `/dashboard/articles/${id}`;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/trash/articles_trash.blade.php ENDPATH**/ ?>