<?php $__env->startSection('content'); ?>
    <div class="section">
        <div class="container">

            <div class="text-center mt-8">
                <h2><?php echo e($article->title); ?></h2>
                <p> in <?php echo e(date('F d, Y', strtotime($article->created_at))); ?> at <?php echo e(date('g:ia')); ?></p>
            </div>


            <div class="text-center my-8">
                <img class="rounded-md" src="<?php echo e(asset('storage/' . $article->image)); ?>" alt="...">
            </div>


            <div class="row">
                <div class="col-lg-8 mx-auto">


                    <hr class="w-100px">

                    <div class="article lead-2">
                        <?php echo $article->description; ?>

                    </div>

                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/articles/get_article.blade.php ENDPATH**/ ?>