        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($category->name); ?></td>
                <td>ليس</td>
                <td>حذف</td>
                <td>تعديل</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $categories->links(); ?>

<?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/categories/load_categories.blade.php ENDPATH**/ ?>