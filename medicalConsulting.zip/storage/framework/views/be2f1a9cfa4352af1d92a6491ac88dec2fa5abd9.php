<?php $__env->startSection('content'); ?>

<div class="container">
    <h3 class="text-secondary">إحصائات الموقع</h3>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                    <div class="card-header ">عدد الأقسام الكلية</div>
                    <div class="card-body text-center">
                        <h5 class="card-title" style="font-size: 3.8rem">
                            <a class="text-white" href="<?php echo e(route('dashboard.categories.index')); ?>"><?php echo e(count($categories)); ?></a>
                        </h5>
                    </div>
                </div>
            </div>

            <div class="card text-white bg-secondary mb-3" style="max-width: 18rem;">
                <div class="card-header">الإســتــشــارات</div>
                <div class="card-body text-center">
                    <h5 class="card-title text-danger" style="font-size: 1.9rem">
                        <span class="text-white"> تم الرد على: </span>
                        <?php echo e(count($consult_rep)); ?>

                        <hr>
                        <span class="text-white"> لم يتم الرد على: </span>
                        <a class="text-danger" href="<?php echo e(route('dashboard.consultations.index')); ?>"><?php echo e(count($consult_not_rep)); ?></a>
                    </h5>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card text-white bg-warning mb-3" style="max-width: 18rem;">
                    <div class="card-header ">عدد المقالات الكلية</div>
                    <div class="card-body text-center">
                        <h5 class="card-title" style="font-size: 3.8rem">
                            <a class="text-white" href="<?php echo e(route('dashboard.articles.index')); ?>"> <?php echo e(count($articles)); ?> </a>
                        </h5>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
                    <div class="card-header ">سلة المحذوفات </div>
                    <div class="card-body text-center">
                        <h5 class="card-title" style="font-size: 3.8rem">
                            <a class="text-white" href="<?php echo e(route('dashboard.trash')); ?>"> <?php echo e($totalTrash); ?> </a>
                        </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/home.blade.php ENDPATH**/ ?>