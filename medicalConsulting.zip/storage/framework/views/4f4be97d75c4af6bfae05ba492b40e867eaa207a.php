    <ul class="list-group">
        <li class="list-group-item"><a href="<?php echo e(route('dashboard.home')); ?>">الرئيسية</a></li>
        <li class="list-group-item"><a href="<?php echo e(route('dashboard.categories.index')); ?>">إدارة الأقسام</a></li>
        <li class="list-group-item"><a href="<?php echo e(route('dashboard.articles.index')); ?>">إدارة المقالات</a></li>
        <li class="list-group-item"><a href="<?php echo e(route('dashboard.consultations.index')); ?>">إدارة الإستشارات</a></li>


    </ul>
    <ul class="list-group mt-3">
        <li class="list-group-item "><a href="<?php echo e(route('dashboard.trash')); ?>" class="text-danger">سلة المحذوفات </a></li>
    </ul>
<?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/partials/sidebar.blade.php ENDPATH**/ ?>