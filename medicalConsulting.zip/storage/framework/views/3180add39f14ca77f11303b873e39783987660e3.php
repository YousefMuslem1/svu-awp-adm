<nav class="navbar navbar-expand-lg  navbar-dark " data-navbar="sticky">
    <div class="container">

        <div class="navbar-left">
            <?php if(!Request::is(['login', 'register'])): ?>
                <button class="navbar-toggler" type="button">&#9776;</button>
            <?php endif; ?>
            <a class="navbar-brand text-warning" style="font-weight: bolder" href="<?php echo e(url('/')); ?>">
                صحتك
            </a>
        </div>

        <section class="navbar-mobile">
            <span class="navbar-divider d-mobile-none"></span>

            <ul class="nav nav-navbar">
                <li class="nav-item">
                    <a class="nav-link" href="#">الأقسام <span class="arrow"></span></a>
                    <ul class="nav">
                        <li class="nav-item">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="nav-link" href="<?php echo e(route('show.categories.articles', $category->id)); ?>"><?php echo e($category->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('ask.consult')); ?>">طلب استشارة</a>
                </li>
                <?php if(Auth::check()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('inbox')); ?>">صندق المراسلات </a>
                    </li>
                <?php endif; ?>
            </ul>
            <ul class="nav nav-navbar ml-auto">
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">تسجيل الدخول</a>
                    </li>
                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>">إنشاء حساب</a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                                تسجيل خروج
                            </a>
                            <a class="dropdown-item" href="#">
                                ملفي الشخصي
                            </a>


                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </section>


    </div>
</nav><!-- /.navbar -->
<?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/partials/navbar.blade.php ENDPATH**/ ?>