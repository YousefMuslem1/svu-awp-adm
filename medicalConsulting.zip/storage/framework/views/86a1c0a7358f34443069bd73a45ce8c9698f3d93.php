<?php $__env->startSection('content'); ?>
    <div class="row ml-3">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-3">
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($category->name); ?>

                    </h5>
                    <p class="card-text">
                        يحوي القسم على  محذوفة<span class="badge badge-success float-left"><?php echo e($category->articles()->withTrashed()->count()); ?></span>
                    </p>

                    <form action="<?php echo e(route('dashboard.categories.restore', $category->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button
                            type="button"
                            class="btn btn-danger"
                            data-toggle="modal"
                            data-name="<?php echo e($category->name); ?>"
                            data-target="#deleteCategory"
                            onclick=handleDelete(<?php echo e($category->id); ?>)
                        >حذف نهائي</button>
                        <button type="submit" class="btn btn-success" data-dismiss="modal">استعادة</button>
                    </form>
                </div>
            </div>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <?php if(count($categories) == 0): ?>
        <div class="alert alert-info lead">لاتوجد أقسام محذوفة </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    //Delete a category
    $('.modal').on('hidden.bs.modal', function (e) {
        $(this).find("#d-head").html('').end()
    })
    // Reset inputs in modal after hiden from user
    $('#deleteCategory').on('show.bs.modal', function (e) {
        var button = $(e.relatedTarget)
        var name = button.data('name');
        var modal = $(this)
        modal.find('.modal-body #d-head').append(name + ' ') ;

    })

    function handleDelete(id) {
    console.log(id)
        var form = document.getElementById('deleteFormCategory');
        form.action = '/dashboard/categories/' + id;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.partials.delete_category_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/trash/category.blade.php ENDPATH**/ ?>