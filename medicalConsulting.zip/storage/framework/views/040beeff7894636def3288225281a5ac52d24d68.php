<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>medicalconsulting</title>

    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <!-- Styles -->
    <?php if(!Request::is(['login', 'register', 'inbox*',])): ?>
        <link href="<?php echo e(asset('/css/client/page.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/css/client/style.min.css')); ?>" rel="stylesheet">
    <?php endif; ?>
    <?php if(Request::is(['login', 'register', 'inbox*'])): ?>
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php endif; ?>
    <?php echo $__env->yieldContent('styles'); ?>
    <style>
        .article {
            direction: rtl;
        }
    </style>
</head>
<body>
            <?php echo $__env->yieldContent('log-reg-nav'); ?>
            <?php if(!Request::is(['login', 'register'])): ?>
                <?php $__env->startSection('top-main'); ?>
                    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldSection(); ?>
            <?php endif; ?>
            <div class="container">
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success mt-4 lead"><?php echo e(session()->get('success')); ?></div>
                <?php endif; ?>
            </div>
        <main id="content">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

            <?php if(!Request::is(['login', 'register'])): ?>
                <script src="<?php echo e(asset('js/client/page.min.js')); ?>"></script>
                <script src="<?php echo e(asset('js/client/script.js')); ?>"> </script>
            <?php endif; ?>




            <!-- Footer -->
            <?php $__env->startSection('footer'); ?>
            <footer class="footer">
                <div class="container">
                    <div class="row gap-y align-items-center">

                        <div class="col-md-3 text-center text-md-left">
                            <a href="<?php echo e(url('/')); ?>">صحتك</a>
                        </div>

                        <div class="col-md-6">
                            <div class="nav nav-center">
                                <a class="nav-link" href="<?php echo e(route('ask.consult')); ?>">استشارة</a>
                                <a class="nav-link" href="#">الخصوصية</a>
                                <a class="nav-link" href="#">من نحن</a>
                                <a class="nav-link" href="#content">مقالات</a>
                            </div>
                        </div>

                        <div class="col-md-3 text-center text-md-right">
                            <small>© 2020. جميع الحقوق محفوظة .</small>
                        </div>
                    </div>
                </div>
            </footer><!-- /.footer -->
            <?php echo $__env->yieldSection(); ?>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"></script>
        <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/layouts/app.blade.php ENDPATH**/ ?>