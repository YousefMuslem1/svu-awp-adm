<?php $__env->startSection('content'); ?>
    <h2 class="text-secondary">إدارة الأقسام</h2>
    <hr>
    <button
        class="btn btn-success mb-2 lead"
        data-toggle="modal"
        data-target="#addCategory"
        style="cursor: pointer">
        <i class="fas fa-plus mr-2"></i>
        إضافة قسم</button>
        <?php echo $__env->make('dashboard.partials.add_category_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('dashboard.partials.edit_category_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('dashboard.partials.delete_category_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card card-default">
        <div class="card-header">
            الأقسام الرئيسية
        </div>
        <div class="card-body">

            <table class="table table-hover">
                <thead>
                <th>اسم القسم</th>
                <th>عدد المواضيع</th>
                <th>تاريخ الإنشاء</th>
                <th>حذف</th>
                <th>تعديل</th>
                </thead>
                <tbody class="lead categories">

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="name"><a href="<?php echo e(route('dashboard.categories.articles', $category->id)); ?>"><?php echo e($category->name); ?></a></td>
                        <td>
                            <a href="<?php echo e(route('dashboard.categories.articles', $category->id)); ?>">
                                <span class="badge badge-warning"><?php echo e($category->articles->count()); ?></span>
                            </a>
                        </td>
                        <td style="font-size: .8rem">
                            <?php echo e(date('F d, Y', strtotime($category->created_at))); ?> at <?php echo e(date('g:ia')); ?>

                        </td>
                        <td>
                            <button
                                class="btn btn-danger btn-sm"
                                onclick="handleDelete(<?php echo e($category->id); ?>)"
                                data-toggle="modal"
                                data-target="#deleteCategory"
                                data-name='<?php echo e($category->name); ?>'
                                    style="cursor: pointer"
                                    >حذف</button>
                        </td>
                        <td><button
                                    class="btn btn-info btn-sm"
                                    data-toggle="modal"
                                    data-target="#editCategory"
                                    data-name='<?php echo e($category->name); ?>'
                                        data-id = '<?php echo e($category->id); ?>'
                                    style="cursor: pointer"
                                     >تعديل</button>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo $categories->links(); ?>

        <?php if(count($categories) == 0): ?>
                <div class="alert alert-info">لم تتم إضافة أقسام بعد
                    <button
                        class="btn btn-link"
                        data-toggle="modal"
                        data-target="#addCategory"
                        style="cursor: pointer"
                    >أنشئ الآن</button>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        // Reset inputs in modal after hiden from user
        $('.modal').on('hidden.bs.modal', function (e) {
            $(this).find("input").val('').end()
        })
        // send Ajax Request To Store a category
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $("#addNewCategory").submit(function(e){
            e.preventDefault();
            var data = $('#addNewCategory').serialize();
            console.log(data);
            var url = '<?php echo e(route('dashboard.categories.store')); ?>';
            $.ajax({
                url:url,
                method:'POST',
                data: data,
                success:function(response){
                    if(response.success){
                        $('.modal').modal('hide');

                        alert(response.message) ;//Message come from controller
                        location.reload();
                    }else{
                        alert(response.message)
                    }
                },

            });
        });

        // Send Ajax request for edit a category
        $('#editCategory').on('show.bs.modal', function (e) {
            var button = $(e.relatedTarget)
            var name = button.data('name');
            var id = button.data('id');

            var modal = $(this)
            modal.find('.modal-body #name').val(name);
            modal.find('.modal-body #id').val(id);
        })
        // send Ajax Request To Store Data
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $("#editCategory").submit(function(e){
            e.preventDefault();
            var data = $('#editFormCategory').serialize();
            console.log(data)
            var url = '<?php echo e(url('/')); ?>/dashboard/categories/up'
            $.ajax({
                url:url,
                method:'PUT',
                data: data,
                success:function(response){
                    if(response.success){
                        $('.modal').modal('hide');

                        alert(response.message) ;//Message come from controller
                        location.reload();
                    }else{
                        alert(response.message)
                    }
                },

            });
        });


        //Delete a category
        $('.modal').on('hidden.bs.modal', function (e) {
            $(this).find("#d-head").html('').end()
        })
        // Reset inputs in modal after hiden from user
        $('#deleteCategory').on('show.bs.modal', function (e) {
            var button = $(e.relatedTarget)
            var name = button.data('name');
            var modal = $(this)
            modal.find('.modal-body #d-head').append(name + ' ') ;

        })

        function handleDelete(id) {

            var form = document.getElementById('deleteFormCategory');
            form.action = `/dashboard/categories/${id}`
        }

        $('.name').limitText({
            length: 35,
            ellipsisText: '...'
        }).css('color', '#800000');

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicalConsulting\resources\views/dashboard/categories/index.blade.php ENDPATH**/ ?>